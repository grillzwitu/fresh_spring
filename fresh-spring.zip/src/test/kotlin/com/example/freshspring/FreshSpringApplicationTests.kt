package com.example.freshspring

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FreshSpringApplicationTests {

	@Test
	fun contextLoads() {
	}

}
